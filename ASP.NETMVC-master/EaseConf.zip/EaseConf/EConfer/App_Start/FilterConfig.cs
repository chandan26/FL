﻿using System.Web;
using System.Web.Mvc;

namespace EConfer
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
        //auto created
    }
}
