﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EConfer.Models;


namespace EConfer.Controllers
{
    public class SpeakerController : Controller
    {
        // GET: Speaker view in browser
        public ActionResult Index()
        {
            using (TestDBEntities tbde = new TestDBEntities())
            {
                return View(tbde.SpeakerTbls.ToList());
            }
        }

        // GET: Speaker/Details/5
        public ActionResult Details(int id)
        {
            using (TestDBEntities tsdb=new TestDBEntities())
                return View(tsdb.SpeakerTbls.Where(x =>x.SpeakerID==id).FirstOrDefault());
        }

        // GET: Speaker/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Speaker/Create
        [HttpPost]
        public ActionResult Create(SpeakerTbl speak)
        {
            try
            {
                using (TestDBEntities tbd = new TestDBEntities())
                {
                    tbd.SpeakerTbls.Add(speak);
                    tbd.SaveChanges();
                }


                    return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Speaker/Edit/5
        public ActionResult Edit(int id)
        {
            using (TestDBEntities tbdt = new TestDBEntities())

            {
                return View(tbdt.Papertbls.Where(x =>x.AuthorID==id).FirstOrDefault());
            }
        }

        // POST: Speaker/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, SpeakerTbl spkr)
        {
            try
            {
                using (TestDBEntities tdbs=new TestDBEntities())
                {
                    tdbs.Entry(spkr).State = EntityState.Modified;
                    tdbs.SaveChanges();

                }
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Speaker/Delete/5
        public ActionResult Delete(int id)
        {
            using (TestDBEntities dbm=new TestDBEntities())
                return View(dbm.SpeakerTbls.Where(x =>x.SpeakerID==id).FirstOrDefault());
        }

        // POST: Speaker/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                using (TestDBEntities tbe = new TestDBEntities())

                {
                    SpeakerTbl spkr = tbe.SpeakerTbls.Where(x => x.SpeakerID == id).FirstOrDefault();
                    tbe.SpeakerTbls.Remove(spkr);
                    tbe.SaveChanges();
                }
                    // TODO: Add delete logic here

                    return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
