﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EConfer.Models;

namespace EConfer.Controllers
{
    public class ConferenceController : Controller
    {

        // GET: Conference
        TestDBEntities tbs = new TestDBEntities();

        public ActionResult Index()
        {
            using (TestDBEntities tesDB= new TestDBEntities())
                return View(tesDB.Conferencedtls.ToList());
        }

        // GET: Conference/Details/5
       
        public ActionResult Details(int id=0)
           
        {
            using (TestDBEntities ted = new TestDBEntities())
            {
                return View(ted.Conferencedtls.Where(x =>x.ConferenceID==id).FirstOrDefault());

            }

                

        }

        // GET: Conference/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Conference/Create
        [HttpPost]
        public ActionResult Create(Conferencedtl conofer)
        {
            try
            {
                using (TestDBEntities tesDB = new TestDBEntities())
                {
                    tesDB.Conferencedtls.Add(conofer);
                    tesDB.SaveChanges();



                }
                    // TODO: Add insert logic here

                    return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Conference/Edit/5
        public ActionResult Edit(int? id)
        {
            using (TestDBEntities ted = new TestDBEntities())
            {
                return View(ted.Conferencedtls.Where(x => x.ConferenceID == id).FirstOrDefault());

            }
        }

        // POST: Conference/Edit/5
        [HttpPost]
        public ActionResult Edit(int? id, Conferencedtl condtl)
        {
            try
            {
                using (TestDBEntities tesd = new TestDBEntities())
                {
                    //return View(ted.Conferencedtls.Where(x => x.ConferenceID == id).FirstOrDefault());
                    tesd.Entry(condtl).State = EntityState.Modified;
                    tesd.SaveChanges();
                    


                }
                return RedirectToAction("Index");
                // TODO: Add update logic here


            }
            catch
            {
                return View();
            }
        }

        // GET: Conference/Delete/5
        public ActionResult Delete(int? id)
        {
            using (TestDBEntities tsdb= new TestDBEntities())

            {
                return View(tsdb.Conferencedtls.Where(x => x.ConferenceID == id).FirstOrDefault());

            }
            //return View();
        }

        // POST: Conference/Delete/5
        [HttpPost]
        public ActionResult Delete(int? id, Conferencedtl cond)
        {
            try
            {
                using (TestDBEntities db = new TestDBEntities())
                {
                    Conferencedtl condtl=db.Conferencedtls.Where(x =>x.ConferenceID==id).FirstOrDefault();
                    db.Conferencedtls.Remove(condtl);
                    db.SaveChanges(); 
                }
                    // TODO: Add delete logic here

                    return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
