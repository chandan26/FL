﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EConfer.Models;

namespace EConfer.Controllers
{
    public class PaperController : Controller
    {
        // GET: Paper
        public ActionResult Index()
        {
            using (TestDBEntities tbds=new TestDBEntities())
                return View(tbds.Papertbls.ToList());
        }
        //forPaper view page

        // GET: Paper/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Paper/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Paper/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Paper/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Paper/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Paper/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Paper/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
